### Adaptive square root optimization algorithm 

This is new proposed optimization algorithm for deep neural network models. The source 
[Second-order information in first-order optimization algorithm](https://arxiv.org/pdf/1912.09926.pdf). For further information and review.  


